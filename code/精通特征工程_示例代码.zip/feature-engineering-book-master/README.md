# feature-engineering-book
This repo accompanies "Feature Engineering for Machine Learning," by Alice Zheng and Amanda Casari. O'Reilly, 2018.

The repo does not contain the data because we do not have rights to disseminate them. Please follow the URLs given in the book to download the data.
